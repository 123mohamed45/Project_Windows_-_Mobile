# Windows-10x
Windows 10x in html/css/javascript plz help me in this project made after 4 months started when Cygnus OS 1.0 devlopment started in Scratch.mit.edu
